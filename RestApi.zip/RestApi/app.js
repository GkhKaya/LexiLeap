const express = require("express");
const bodyParser = require("body-parser");
const app = express();

const wordsRouter = require("./router/words");
app.use("/words",wordsRouter);
app.use(bodyParser.json());

module.exports = app;