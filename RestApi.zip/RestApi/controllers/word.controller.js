const Validator = require("fastest-validator");
const models = require("../models");

function add(req, res) {
    
    const word = {
        name: req.body.name,
        level: req.body.level
    };

    const schema = {
        name: {type: "string", required: true},
        level: {type: "number", required: true},
    }

    const v = new Validator();
    const validationResponse = v.validate(words, schema);

    if (validationResponse.valid) {
        models.Word.create(words).then((result) => {
            res.status(201).json(result);
            message: "Validation failed 201"

        }).catch((err) => {
            res.status(500).json({error: err});
            message: "Validation failed 500 1"

        });
    }
    models.Word.create(word).then((result) => {
        res.status(201).json({
            message: "Announcement created successfully",
            word: result
        })

    }).catch((err) => {
        res.status(500).json({error: err});
        message: 'Something went wrong 500 2'

    });
}

function findById(req, res) {
    const id = req.params.id;
    models.Word.findByPk(id).then((result) => {
        if (result) {
            res.status(200).json(result);
        } else {
            res.status(404).json({error: "Word not found"});
        }
    }).catch((err) => {
        res.status(500).json({error: err});
        message: 'Something went wrong 500 3'
    });
}

function findAll(req,res){
    models.Word.findAll().then((result) => {
        res.status(200).json(result);
    }).catch((err) => {
        res.status(500).json({error: err});
        message: 'Something went wrong 4'

    });
}

module.exports = {
    add : add,
    findById: findById,
    findAll: findAll
};

