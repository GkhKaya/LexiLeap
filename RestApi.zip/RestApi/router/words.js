const express = require('express');
const wordController = require('../controllers/word.controller');
const router = express.Router();

router.post('/', wordController.add);
router.get('/', wordController.findAll);
router.get('/:id', wordController.findById);

module.exports = router;